package com.hospital.backend.dto;


public class LoginResponse {

    private String message;
    private String role;       // "patient" or "doctor"
    private String patientId;  // For patient login
    private String doctorId;   // For doctor login
    private String username;   // Full name of the user
    private String FullName;
    // Default constructor

    public LoginResponse() {}


    public LoginResponse(String message, String role, String patientId, String doctorId, String username, String FullName) {
        this.message = message;
        this.role = role;
        this.patientId = patientId;
        this.doctorId = doctorId;
        this.username = username;
        this.FullName = FullName;
    }

    // Partial constructor (e.g., for error responses)
    public LoginResponse(String message, String role) {
        this.message = message;
        this.role = role;
    }

    // Getters
    public String getMessage() {
        return message;
    }

    public String getRole() {
        return role;
    }

    public String getPatientId() {
        return patientId;
    }

    public String getDoctorId() {
        return doctorId;
    }

    public String getUsername() {
        return username;
    }

    public String getFullName() {
        return FullName;
    }


    // Setters
    public void setMessage(String message) {
        this.message = message;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public void setPatientId(String patientId) {
        this.patientId = patientId;
    }

    public void setDoctorId(String doctorId) {
        this.doctorId = doctorId;
    }

    public void setUsername(String username) {
        this.username = username;
    }
    public void setFullName(String fullName) {
        this.FullName = fullName;
    }
}
