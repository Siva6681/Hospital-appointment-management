package com.hospital.backend.dto;

public class LoginRequest {
    private String email;
    private String password;
    private String role;
    private String patientId; // Used only for patient login

    // Getters
    public String getEmail() {
        return email;
    }

    public String getPassword() {
        return password;
    }

    public String getRole() {
        return role;
    }

    public String getPatientId() {
        return patientId;
    }

    // Setters
    public void setEmail(String email) {
        this.email = email;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public void setPatientId(String patientId) {
        this.patientId = patientId;
    }
}
