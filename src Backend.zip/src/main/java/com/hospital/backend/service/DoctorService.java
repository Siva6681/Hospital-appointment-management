package com.hospital.backend.service;

import com.hospital.backend.dto.AppointmentResponse;
import com.hospital.backend.model.Appointment;
import com.hospital.backend.model.Doctor;
import com.hospital.backend.model.Patient;
import com.hospital.backend.repository.AppointmentRepository;
import com.hospital.backend.repository.DoctorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Service
public class DoctorService {

    @Autowired
    private DoctorRepository doctorRepository;

    @Autowired
    private AppointmentRepository appointmentRepository;

    public Doctor registerDoctor(Doctor doctor) {
        String generatedId = "DID-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
        doctor.setDoctorId(generatedId);
        return doctorRepository.save(doctor);
    }


    // Get all doctors
    public List<Doctor> getAllDoctors() {
        return doctorRepository.findAll();
    }

    // Get distinct specialties
    public List<String> getAllSpecialties() {
        return doctorRepository.findDistinctSpecialties();
    }

    // Get doctors by specialty
    public List<Doctor> getDoctorsBySpecialty(String specialty) {
        return doctorRepository.findBySpecialty(specialty);
    }

    // Get doctor by ID
    public Doctor getDoctorById(String doctorId) {
        return doctorRepository.findById(doctorId).orElse(null);
    }

    // Update doctor by ID
    public Doctor updateDoctor(String doctorId, Doctor updatedDoctor) {
        return doctorRepository.findById(doctorId).map(existingDoctor -> {
            existingDoctor.setName(updatedDoctor.getName());
            existingDoctor.setEmail(updatedDoctor.getEmail());
            existingDoctor.setPhoneNumber(updatedDoctor.getPhoneNumber());
            existingDoctor.setSpecialty(updatedDoctor.getSpecialty());
            existingDoctor.setAge(updatedDoctor.getAge());
            existingDoctor.setGender(updatedDoctor.getGender());
            if (updatedDoctor.getPassword() != null && !updatedDoctor.getPassword().isEmpty()) {
                existingDoctor.setPassword(updatedDoctor.getPassword());
            }
            return doctorRepository.save(existingDoctor);
        }).orElse(null);
    }

    // Delete doctor by ID
    public boolean deleteDoctor(String doctorId) {
        if (doctorRepository.existsById(doctorId)) {
            doctorRepository.deleteById(doctorId);
            return true;
        }
        return false;
    }

    // Get appointments by patient ID with doctor details
    public List<AppointmentResponse> getAppointmentsByPatient(String patientId) {
        List<Appointment> appointments = appointmentRepository.findByPatientId(patientId);
        List<AppointmentResponse> responses = new ArrayList<>();
        for (Appointment appointment : appointments) {
            AppointmentResponse response = new AppointmentResponse();
            response.setAppointmentId(appointment.getAppointmentId());
            response.setPatientId(appointment.getPatientId());
            response.setTimeSlot(appointment.getTimeSlot());
            response.setCause(appointment.getCause());
            response.setBodyMass(appointment.getBodyMass());
            response.setMedicalHistory(appointment.getMedicalHistory());
            response.setStatus(appointment.getStatus());
            response.setCreatedAt(appointment.getCreatedAt());

            // Fetch doctor details
            Doctor doctor = doctorRepository.findById(appointment.getDoctorId()).orElse(null);
            if (doctor != null) {
                response.setDoctorName(doctor.getName());
                response.setSpecialty(doctor.getSpecialty());
            }
            responses.add(response);
        }
        return responses;
    }

    public Doctor loginDoctor(String email, String password, String doctorId) {
        return doctorRepository.findByEmailAndPasswordAndDoctorId(email, password, doctorId);

    }
}
