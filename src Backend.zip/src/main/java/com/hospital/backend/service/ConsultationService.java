package com.hospital.backend.service;

import com.hospital.backend.model.Consultation;
import com.hospital.backend.model.Appointment;
import com.hospital.backend.repository.ConsultationRepository;
import com.hospital.backend.repository.AppointmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.UUID;

@Service
public class ConsultationService {

    @Autowired
    private ConsultationRepository consultationRepository;

    @Autowired
    private AppointmentRepository appointmentRepository;

    public Consultation saveConsultation(Consultation consultation) {
        consultation.setConsultationId("CONS-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase());
        consultation.setCreatedAt(LocalDateTime.now());

        // Mark appointment as completed
        Appointment appointment = appointmentRepository.findByAppointmentId(consultation.getAppointmentId());
        appointment.setStatus("Completed");
        appointmentRepository.save(appointment);

        return consultationRepository.save(consultation);
    }

    public Consultation getConsultationByAppointmentId(String appointmentId) {
        return consultationRepository.findByAppointmentId(appointmentId)
                .orElseThrow(() -> new RuntimeException("Consultation not found"));
    }
}
