package com.hospital.backend.service;

import com.hospital.backend.model.Appointment;
import com.hospital.backend.repository.AppointmentRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Service
public class AppointmentService {

    @Autowired
    private AppointmentRepository appointmentRepository;

    // Generate readable appointment ID like APT001
    private String generateAppointmentId() {
        String generatedId = "AID-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
        return generatedId;
    }

    // Book an appointment if slot is available
    public Appointment bookAppointment(Appointment appointment) {
        List<Appointment> existing = appointmentRepository.findByDoctorIdAndTimeSlot(
                appointment.getDoctorId(), appointment.getTimeSlot());

        if (!existing.isEmpty()) {
            throw new RuntimeException("Time slot already booked for this doctor.");
        }

        appointment.setAppointmentId(generateAppointmentId());
        appointment.setCreatedAt(LocalDateTime.now());
        return appointmentRepository.save(appointment);
    }

    // Get appointments for a patient
    public List<Appointment> getAppointmentsByPatient(String patientId) {
        return appointmentRepository.findByPatientId(patientId);
    }

    // Get appointments for a doctor (used to filter booked slots)
    public List<Appointment> getAppointmentsByDoctor(String doctorId) {
        return appointmentRepository.findByDoctorId(doctorId);
    }

    // Delete an appointment by ID
    @Transactional
    public boolean deleteAppointment(String appointmentId) {
        if (appointmentRepository.existsByAppointmentId(appointmentId)) {
            appointmentRepository.deleteByAppointmentId(appointmentId);
            return true;
        }
        return false;
    }


    public Appointment getAppointmentById(String appointmentId) {
        return appointmentRepository.findByAppointmentId(appointmentId);
    }
}
