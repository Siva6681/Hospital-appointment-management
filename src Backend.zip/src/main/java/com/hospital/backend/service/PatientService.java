package com.hospital.backend.service;

import com.hospital.backend.model.Patient;
import com.hospital.backend.repository.PatientRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
public class PatientService {

    @Autowired
    private PatientRepository patientRepository;

    // ✅ Registration with patientId generation
    public Patient registerPatient(Patient patient) {
        String generatedId = "PID-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
        patient.setPatientId(generatedId);
        return patientRepository.save(patient);
    }

    // ✅ Login using email, password, and patientId
    public Patient loginPatient(String email, String password, String patientId) {
        return patientRepository.findByEmailAndPasswordAndPatientId(email, password, patientId);
    }

    // ✅ Fetch patient by patientId
    public Patient getPatientByPatientId(String patientId) {
        return patientRepository.findByPatientId(patientId);
    }

    // ✅ Update patient profile
    public Patient updatePatient(String patientId, Patient updatedData) {
        Patient existing = patientRepository.findByPatientId(patientId);
        if (existing != null) {
            existing.setFullName(updatedData.getFullName());
            existing.setEmail(updatedData.getEmail());
            existing.setPhoneNumber(updatedData.getPhoneNumber());
            existing.setAge(updatedData.getAge());
            existing.setGender(updatedData.getGender());
            return patientRepository.save(existing);
        }
        return null;
    }
}
