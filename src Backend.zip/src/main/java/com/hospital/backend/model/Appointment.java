package com.hospital.backend.model;

import jakarta.persistence.*;

import java.time.LocalDateTime;

import lombok.*;


@Entity
@Table(name = "appointments")
@Setter
@Getter
public class Appointment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true)
    private String appointmentId;


    @Column(name = "patientid", nullable = false)
    private String patientId;

    @Column(name = "doctor_id", nullable = false)
    private String doctorId;

    @Column(name = "time_slot", nullable = false)
    private String timeSlot;

    @Column(name = "cause")
    private String cause;

    @Column(name = "body_mass")
    private double bodyMass;

    @Column(name = "medical_history")
    private String medicalHistory;

    @Column(name = "status")
    private String status;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    public Appointment() {
        this.status = "Booked";
        this.createdAt = LocalDateTime.now();
    }
}
