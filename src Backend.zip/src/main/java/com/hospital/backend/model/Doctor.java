package com.hospital.backend.model;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "doctors")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Doctor {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true)
    private String doctorId; // e.g., "DOC001"

    private String name;

    @Column(unique = true)
    private String email;
    private String password;
    private String phoneNumber;
    private String specialty;
    private int age;
    private String gender;

    public String getFullName() {
        return name;
    }

    public void setFullName(String fullName) {
        this.name = fullName;
    }
}
