// model/Consultation.java
package com.hospital.backend.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
public class Consultation {
    @Id
    private String consultationId;

    private String appointmentId;
    private String patientId;
    private String doctorId;

    @Column(columnDefinition = "TEXT")
    private String prescription;

    @Column(columnDefinition = "TEXT")
    private String consultationNotes;

    private LocalDateTime createdAt;

    // Getters and Setters
    public String getConsultationId() {
        return consultationId;
    }
    public void setConsultationId(String consultationId) {
        this.consultationId = consultationId;
    }
    public String getAppointmentId() {
        return appointmentId;
    }
    public void setAppointmentId(String appointmentId) {
        this.appointmentId = appointmentId;
    }
    public String getPatientId() {
        return patientId;
    }
    public void setPatientId(String patientId) {
        this.patientId = patientId;
    }
    public String getDoctorId() {
        return doctorId;
    }
    public void setDoctorId(String doctorId) {
        this.doctorId = doctorId;
    }
    public String getPrescription() {
        return prescription;
    }
    public void setPrescription(String prescription) {
        this.prescription = prescription;
    }
    public String getConsultationNotes() {
        return consultationNotes;
    }
    public void setConsultationNotes(String consultationNotes) {
        this.consultationNotes = consultationNotes;
    }
    public LocalDateTime getCreatedAt() {
        return createdAt;
    }
    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }
}
