package com.hospital.backend.repository;

import com.hospital.backend.model.Consultation;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface ConsultationRepository extends JpaRepository<Consultation, String> {
    Optional<Consultation> findByAppointmentId(String appointmentId);
}
