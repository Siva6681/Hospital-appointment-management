package com.hospital.backend.repository;

import com.hospital.backend.model.Patient;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PatientRepository extends JpaRepository<Patient, Long> {

    // Find by email only
    Patient findByEmail(String email);

    // Find by email and password
    Patient findByEmailAndPassword(String email, String password);

    // ✅ New: Find by email, password, and patientId for login
    Patient findByEmailAndPasswordAndPatientId(String email, String password, String patientId);

    // ✅ Optional: Find by patientId alone (for dashboard fetch)
    Patient findByPatientId(String patientId);
}
