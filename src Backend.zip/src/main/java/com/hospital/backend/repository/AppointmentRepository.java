package com.hospital.backend.repository;

import com.hospital.backend.model.Appointment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AppointmentRepository extends JpaRepository<Appointment, String> {

    List<Appointment> findByDoctorIdAndTimeSlot(String doctorId, String timeSlot);

    List<Appointment> findByPatientId(String patientId);

    List<Appointment> findByDoctorId(String doctorId);

    Appointment findByAppointmentId(String appointmentId);

    boolean existsByAppointmentId(String appointmentId);
    void deleteByAppointmentId(String appointmentId);

}
