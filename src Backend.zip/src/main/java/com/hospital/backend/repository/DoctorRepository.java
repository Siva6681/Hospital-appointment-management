package com.hospital.backend.repository;

import com.hospital.backend.model.Doctor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface DoctorRepository extends JpaRepository<Doctor, String> {
    Doctor findByEmailAndPassword(String email, String password);
    List<Doctor> findBySpecialty(String specialty);
    Doctor findByEmailAndPasswordAndDoctorId(String email, String password, String doctorId);
    @Query("SELECT DISTINCT d.specialty FROM Doctor d")
    List<String> findDistinctSpecialties();

    Doctor findByEmail(String email);
}
