package com.hospital.backend.controller;

import com.hospital.backend.dto.LoginRequest;
import com.hospital.backend.dto.LoginResponse;
import com.hospital.backend.model.Doctor;
import com.hospital.backend.repository.DoctorRepository;
import com.hospital.backend.service.DoctorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/doctors")
@CrossOrigin(origins = "http://localhost:3000")
public class DoctorController {

    @Autowired
    private DoctorService doctorService;

    @Autowired
    private DoctorRepository doctorRepository;

    // ✅ Doctor Login using LoginRequest DTO
    @PostMapping("/login")
    public ResponseEntity<?> loginPatient(@RequestParam String email,
                                          @RequestParam String password,
                                          @RequestParam String doctorId) {
        Doctor loggedInDoctor = doctorService.loginDoctor(email, password, doctorId);
        if (loggedInDoctor != null) {
            return ResponseEntity.ok(loggedInDoctor);
        } else {
            return ResponseEntity.status(401).body("Invald credentials");
        }
    }


    // ✅ Get all doctors
    @GetMapping("")
    public List<Doctor> getAllDoctors() {
        return doctorService.getAllDoctors();
    }

    // ✅ Register a new doctor
    @PostMapping("/register")
    public ResponseEntity<Doctor> registerDoctor(@RequestBody Doctor doctor) {
        Doctor savedDoctor = doctorService.registerDoctor(doctor);
        return ResponseEntity.ok(savedDoctor);
    }

    // ✅ Get all specialties
    @GetMapping("/specialties")
    public List<String> getAllSpecialties() {
        return doctorService.getAllSpecialties();
    }

    // ✅ Get doctors by specialty
    @GetMapping("/by-specialty")
    public List<Doctor> getDoctorsBySpecialty(@RequestParam String specialty) {
        return doctorService.getDoctorsBySpecialty(specialty);
    }

    // ✅ Get doctor by ID
    @GetMapping("/{doctorId}")
    public ResponseEntity<Doctor> getDoctorById(@PathVariable String doctorId) {
        Doctor doctor = doctorService.getDoctorById(doctorId);
        if (doctor != null) {
            return ResponseEntity.ok(doctor);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    // ✅ Update doctor by ID
    @PutMapping("/{doctorId}")
    public ResponseEntity<Doctor> updateDoctor(@PathVariable String doctorId, @RequestBody Doctor updatedDoctor) {
        Doctor doctor = doctorService.updateDoctor(doctorId, updatedDoctor);
        if (doctor != null) {
            return ResponseEntity.ok(doctor);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    // ✅ Delete doctor by ID
    @DeleteMapping("/{doctorId}")
    public ResponseEntity<String> deleteDoctor(@PathVariable String doctorId) {
        boolean deleted = doctorService.deleteDoctor(doctorId);
        if (deleted) {
            return ResponseEntity.ok("Doctor deleted successfully.");
        } else {
            return ResponseEntity.notFound().build();
        }
    }




}
