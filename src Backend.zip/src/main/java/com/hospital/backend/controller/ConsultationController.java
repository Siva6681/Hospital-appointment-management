package com.hospital.backend.controller;

import com.hospital.backend.model.Consultation;
import com.hospital.backend.service.ConsultationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/consultations")
@CrossOrigin(origins = "http://localhost:3000")
public class ConsultationController {

    @Autowired
    private ConsultationService consultationService;

    @PostMapping
    public ResponseEntity<?> saveConsultation(@RequestBody Consultation consultation) {
        Consultation saved = consultationService.saveConsultation(consultation);
        System.out.println(saved);
        return ResponseEntity.ok(saved);
    }

    @GetMapping("/appointment/{appointmentId}")
    public ResponseEntity<?> getConsultationByAppointmentId(@PathVariable String appointmentId) {
        try {
            Consultation consultation = consultationService.getConsultationByAppointmentId(appointmentId);
            return ResponseEntity.ok(consultation);
        } catch (Exception e) {
            return ResponseEntity.status(404).body("Consultation not found.");
        }
    }
}
