package com.hospital.backend.controller;

import com.hospital.backend.dto.AppointmentResponse;
import com.hospital.backend.model.Appointment;
import com.hospital.backend.model.Patient;
import com.hospital.backend.service.AppointmentService;
import com.hospital.backend.service.DoctorService;
import com.hospital.backend.service.PatientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/patients")
@CrossOrigin(origins = "http://localhost:3000")
public class PatientController {

    @Autowired
    private PatientService patientService;

    @Autowired
    private AppointmentService appointmentService;
    @Autowired
    private DoctorService doctorService;


    // ✅ Register patient and return full details including generated patientId
    @PostMapping("/register")
    public ResponseEntity<Patient> registerPatient(@RequestBody Patient patient) {
        Patient savedPatient = patientService.registerPatient(patient);
        return ResponseEntity.ok(savedPatient);
    }

    // ✅ Login using email, password, and patientId
    @PostMapping("/login")
    public ResponseEntity<?> loginPatient(@RequestParam String email,
                                          @RequestParam String password,
                                          @RequestParam String patientId) {
        Patient loggedInPatient = patientService.loginPatient(email, password, patientId);
        if (loggedInPatient != null) {
            return ResponseEntity.ok(loggedInPatient);
        } else {
            return ResponseEntity.status(401).body("Invald credentials");
        }
    }

    // ✅ Get patient details by patientId (for dashboard)
    @GetMapping("/{patientId}")
    public ResponseEntity<?> getPatientById(@PathVariable String patientId) {
        Patient patient = patientService.getPatientByPatientId(patientId);
        if (patient != null) {
            return ResponseEntity.ok(patient);
        } else {
            return ResponseEntity.status(404).body("Patient not found");
        }
    }

    // ✅ Get appointments for a patient
    @GetMapping("/patient/details/{patientId}")
    public ResponseEntity<List<AppointmentResponse>> getDetailedAppointmentsByPatientId(@PathVariable String patientId) {
        List<AppointmentResponse> responses = doctorService.getAppointmentsByPatient(patientId);
        return ResponseEntity.ok(responses);
    }

    @PutMapping("/{patientId}")
    public ResponseEntity<String> updatePatient(@PathVariable String patientId, @RequestBody Patient updatedData) {
        Patient updated = patientService.updatePatient(patientId, updatedData);
        return updated != null ? ResponseEntity.ok("Updated successfully") : ResponseEntity.notFound().build();
    }
}
