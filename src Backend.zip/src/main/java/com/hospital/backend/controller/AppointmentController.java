package com.hospital.backend.controller;

import com.hospital.backend.dto.AppointmentResponse;
import com.hospital.backend.model.Appointment;
import com.hospital.backend.model.Patient;
import com.hospital.backend.service.AppointmentService;
import com.hospital.backend.service.PatientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/appointments")
@CrossOrigin(origins = "http://localhost:3000", allowCredentials = "true")
public class AppointmentController {

    @Autowired
    private AppointmentService appointmentService;

    @Autowired PatientService patientService;

    // Book an appointment
    @PostMapping
    public ResponseEntity<?> bookAppointment(@RequestBody Appointment appointment) {
        try {
            Appointment savedAppointment = appointmentService.bookAppointment(appointment);
            return ResponseEntity.ok(savedAppointment);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(500).body("Internal Server Error: " + e.getMessage());
        }
    }

    // Get appointments for a specific patient (used by frontend with patientId)
    @GetMapping("/patient/{patientId}")
    public ResponseEntity<?> getAppointmentsByPatientId(@PathVariable String patientId) {
        List<Appointment> appointments = appointmentService.getAppointmentsByPatient(patientId);
        return ResponseEntity.ok(appointments);
    }

    // Get booked slots for a doctor
    @GetMapping("/doctor/{doctorId}")
    public List<Appointment> getAppointmentsByDoctor(@PathVariable String doctorId) {
        return appointmentService.getAppointmentsByDoctor(doctorId);
    }

    // Delete an appointment by ID
    @DeleteMapping("/{appointmentId}")
    public ResponseEntity<?> deleteAppointment(@PathVariable String appointmentId) {
        boolean deleted = appointmentService.deleteAppointment(appointmentId);
        if (deleted) {
            return ResponseEntity.ok("Appointment deleted successfully.");
        } else {
            return ResponseEntity.status(404).body("Appointment not found.");
        }
    }

//    @GetMapping("/{appointmentId}")
//    public ResponseEntity<?> getAppointmentDetails(@PathVariable String appointmentId) {
//        Appointment appointment = appointmentService.getAppointmentById(appointmentId);
//        if (appointment == null) {
//            return ResponseEntity.status(404).body("Appointment not found.");
//        }
//
//        AppointmentResponse response = new AppointmentResponse();
//        response.setAppointmentId(appointment.getAppointmentId());
//        response.setPatientId(appointment.getPatientId());
//        response.setTimeSlot(appointment.getTimeSlot());
//        response.setCause(appointment.getCause());
//        response.setBodyMass(appointment.getBodyMass());
//        response.setMedicalHistory(appointment.getMedicalHistory());
//        response.setStatus(appointment.getStatus());
//        response.setCreatedAt(appointment.getCreatedAt());
//
//        // Optional: enrich with patient name
//        Patient patient = patientService.getPatientByPatientId(appointment.getPatientId());
//        if (patient != null) {
//            response.setPatientName(patient.getFullName());
//            response.setPatientAge(patient.getAge());
//            response.setPatientGender(patient.getGender());
//        }
//
//        return ResponseEntity.ok(response);
//    }
}
