package com.hospital.backend.controller;

import com.hospital.backend.dto.LoginRequest;
import com.hospital.backend.dto.LoginResponse;
import com.hospital.backend.model.Doctor;
import com.hospital.backend.model.Patient;
import com.hospital.backend.repository.DoctorRepository;
import com.hospital.backend.repository.PatientRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "http://localhost:3000")
public class LoginController {

    @Autowired
    private DoctorRepository doctorRepository;

    @Autowired
    private PatientRepository patientRepository;

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest request) {
        String email = request.getEmail();
        String password = request.getPassword();
        String role = request.getRole();
        String patientId = request.getPatientId(); // Only used for patient login

        if ("doctor".equalsIgnoreCase(role)) {
            Doctor doctor = doctorRepository.findByEmailAndPassword(email, password);
            if (doctor != null) {
                return ResponseEntity.ok(new LoginResponse(
//                        "Doctor login successful",
//                        "doctor",
                        doctor.getId().toString(),
                        doctor.getFullName()
                ));
            }
        }

        if ("patient".equalsIgnoreCase(role)) {
            Patient patient = patientRepository.findByEmailAndPasswordAndPatientId(email, password, patientId);
            if (patient != null) {
                return ResponseEntity.ok(new LoginResponse(
//                        "Patient login successful",
//                        "patient",
                        patient.getPatientId(),
                        patient.getFullName()
                ));
            }
        }

        return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                .body(new LoginResponse("Invalid credentials", role));
    }

    @PostMapping("/logout")
    public ResponseEntity<String> logout() {
        return ResponseEntity.ok("Logged out successfully");
    }
}
