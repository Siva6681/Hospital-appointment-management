package com.hospital.backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HospitalBackendAppoinmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
