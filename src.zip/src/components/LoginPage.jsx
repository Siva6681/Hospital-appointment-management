import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import '../LoginPage.css';

const LoginPage = () => {
  const navigate = useNavigate();
  
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const [role, setRole] = useState('doctor');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [patientId, setPatientId] = useState('');
  const [doctorId, setDoctorId] = useState('');

  const handleLogin = async (e) => {
    e.preventDefault();

    console.log('=== LOGIN ATTEMPT ===');
    console.log('Role:', role);
    console.log('Email:', email);
    console.log('Password:', password);
    console.log('Doctor ID:', doctorId);
    console.log('Patient ID:', patientId);

    try {
      let response;

      if (role === 'doctor') {
        console.log('Making doctor login request...');
        response = await axios.post('http://localhost:8080/api/doctors/login', null, {
          params: { email, password, doctorId },
          headers: { 'Content-Type': 'application/json' }
        });
      } else if (role === 'patient') {
        console.log('Making patient login request...');
        response = await axios.post('http://localhost:8080/api/patients/login', null, {
          params: { email, password, patientId },
          headers: { 'Content-Type': 'application/json' }
        });
      }

      const data = response.data;
      console.log('=== LOGIN SUCCESS ===');
      console.log('Response data:', data);
      alert(`${role} login successful`);

      if (role === 'patient') {
        localStorage.setItem('patientId', data.patientId);
        localStorage.setItem('patientName', data.name || data.patientName || 'Patient');
        localStorage.setItem('userRole', 'patient');
        setPatientId(data.patientId);
        navigate('/patient-dashboard');
        window.location.reload();
      } else {
        localStorage.setItem('doctorId', data.doctorId);
        localStorage.setItem('doctorName', data.name || data.doctorName || 'Doctor');
        localStorage.setItem('userRole', 'doctor');
        setDoctorId(data.doctorId);
        navigate('/doctor-dashboard');
        window.location.reload();
      }
    } catch (error) {
      console.log('=== LOGIN ERROR ===');
      console.error('Full error:', error);
      console.log('Error response:', error.response);
      console.log('Error status:', error.response?.status);
      console.log('Error data:', error.response?.data);
      const message = error.response?.data || 'Login failed';
      alert(message);
      setEmail('');
      setPassword('');
      setPatientId('');
      setDoctorId('');
    }
  };

  return (
    <div className="login-page">
      <div className="login-container">
        <h2>Login</h2>
        <form className="login-form" onSubmit={handleLogin}>
          <select value={role} onChange={(e) => setRole(e.target.value)} required>
            <option value="doctor">Doctor</option>
            <option value="patient">Patient</option>
          </select>

          <input
            type="email"
            placeholder="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />

          <input
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />

          {/* {role === 'patient' && (
            <input
              type="text"
              placeholder="Patient ID"
              value={patientId}
              onChange={(e) => setPatientId(e.target.value)}
              required
            />
          )} */}

          {/* {role === 'doctor' && (
            <input
              type="text"
              placeholder="Doctor ID"
              value={doctorId}
              onChange={(e) => setDoctorId(e.target.value)}
              required
            />
          )} */}

          <button type="submit">Login</button>
        </form>

        <div className="register-link">
          New User? <a href="/register">Register Here</a>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;