import React, { useState, useEffect } from 'react';
import { FaUserMd, FaSearch, FaCalendarCheck, FaChartLine, FaStethoscope, FaUserEdit, FaBars, FaTimes } from 'react-icons/fa';
import SearchBooking from './SearchBooking';
import ViewDoctorsAppointments from './ViewDoctorsAppointments';
import DoctorProfile from './DoctorProfile';
import '../doctorDashboard.css';
 
const DoctorDashboard = () => {
  const [activeSection, setActiveSection] = useState('dashboard');
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [activeSection]);
  const doctorId = localStorage.getItem('doctorId');
  const doctorName = localStorage.getItem('doctorName') || 'Doctor';

  const renderSection = () => {
    switch (activeSection) {
      case 'searchBooking':
        return <SearchBooking />;
      case 'viewAppointments':
        return <ViewDoctorsAppointments />;
      case 'myProfile':
        return <DoctorProfile />;
      case 'dashboard':
      default:
        return (
          <div className="dashboard-overview">
            <div className="welcome-section">
              <h1>Welcome, Dr. {doctorName}!</h1>
              <p>Manage your appointments and patient consultations</p>
            </div>
            <div className="quick-actions">
              <button className="action-card" onClick={() => setActiveSection('searchBooking')}>
                <FaSearch />
                <h3>Search Appointments</h3>
                <p>Find specific patient appointments</p>
              </button>
              <button className="action-card" onClick={() => setActiveSection('viewAppointments')}>
                <FaCalendarCheck />
                <h3>My Appointments</h3>
                <p>View and manage your schedule</p>
              </button>
              <button className="action-card" onClick={() => setActiveSection('myProfile')}>
                <FaUserEdit />
                <h3>My Profile</h3>
                <p>View and edit your profile</p>
              </button>
            </div>
          </div>
        );
    }
  };
 
  return (
    <div className="doctor-dashboard">
      <div className={`dashboard-sidebar ${sidebarCollapsed ? 'collapsed' : ''}`}>
        <div className="sidebar-header">
          <button className="collapse-btn" onClick={() => setSidebarCollapsed(!sidebarCollapsed)}>
            {sidebarCollapsed ? <FaBars /> : <FaTimes />}
          </button>
          {!sidebarCollapsed && (
            <>
              <FaStethoscope className="user-icon" />
              <div className="user-info">
                <h3>Dr. {doctorName}</h3>
                <p>Doctor ID: {doctorId}</p>
              </div>
            </>
          )}
        </div>
        <nav className="sidebar-nav">
          <button 
            className={activeSection === 'dashboard' ? 'nav-item active' : 'nav-item'} 
            onClick={() => setActiveSection('dashboard')}
            title="Dashboard"
          >
            <FaChartLine /> {!sidebarCollapsed && 'Dashboard'}
          </button>
          <button 
            className={activeSection === 'searchBooking' ? 'nav-item active' : 'nav-item'} 
            onClick={() => setActiveSection('searchBooking')}
            title="Search Appointments"
          >
            <FaSearch /> {!sidebarCollapsed && 'Search Appointments'}
          </button>
          <button 
            className={activeSection === 'viewAppointments' ? 'nav-item active' : 'nav-item'} 
            onClick={() => setActiveSection('viewAppointments')}
            title="My Appointments"
          >
            <FaCalendarCheck /> {!sidebarCollapsed && 'My Appointments'}
          </button>
          <button 
            className={activeSection === 'myProfile' ? 'nav-item active' : 'nav-item'} 
            onClick={() => setActiveSection('myProfile')}
            title="My Profile"
          >
            <FaUserEdit /> {!sidebarCollapsed && 'My Profile'}
          </button>
        </nav>
      </div>
      <div className="dashboard-main">
        {renderSection()}
      </div>
    </div>
  );
};
 
export default DoctorDashboard;