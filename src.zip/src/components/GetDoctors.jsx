import React, { useState, useEffect } from 'react';
import { FaSearch } from 'react-icons/fa';
import DoctorCard from './DoctorCard';
import axios from 'axios';
import '../GetDoctors.css';

const GetDoctors = () => {
    const [doctors, setDoctors] = useState([]);
    const [filteredDoctors, setFilteredDoctors] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [searchTerm, setSearchTerm] = useState('');

    useEffect(() => {
        const fetchDoctors = async () => {
            try {
                const response = await axios.get('http://localhost:8080/api/doctors');
                setDoctors(response.data);
                setFilteredDoctors(response.data);
            } catch (err) {
                setError('Failed to fetch doctors. Please try again later.');
                console.error('API Error:', err);
            } finally {
                setLoading(false);
            }
        };

        fetchDoctors();
    }, []);

    useEffect(() => {
        const filtered = doctors.filter(doctor =>
            doctor.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
            doctor.specialty.toLowerCase().includes(searchTerm.toLowerCase())
        );
        setFilteredDoctors(filtered);
    }, [searchTerm, doctors]);

    if (loading) {
        return <div className="loading">Loading doctors...</div>;
    }

    if (error) {
        return <div className="error">{error}</div>;
    }

    return (
        <div id='getDoctors' className="get-doctors">
            <div className="doctors-header">
                <h1 className="doctors-title">Meet Our Doctors</h1>
                {/* <p className="doctors-subtitle">
                    Our team of experienced medical professionals is dedicated to providing 
                    exceptional healthcare services with compassion and expertise.
                </p> */}
            </div>

            <div className="search-section">
                <div className="search-input-container">
                    <FaSearch className="search-icon" />
                    <input
                        type="text"
                        placeholder="Search doctors by name or specialty..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="search-input"
                    />
                </div>
            </div>

            {filteredDoctors.length > 0 ? (
                <div className="doctors-grid">
                    {filteredDoctors.map(doctor => (
                        <DoctorCard key={doctor.doctorId} doctor={doctor} />
                    ))}
                </div>
            ) : (
                <div className="no-doctors">
                    <p>No doctors found matching your search.</p>
                </div>
            )}
        </div>
    );
};

export default GetDoctors;