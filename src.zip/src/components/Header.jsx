import React, { useState, useEffect, useRef } from 'react';
import { FaHome, FaSignInAlt, FaUser, FaSignOutAlt, FaChevronDown } from 'react-icons/fa';
import { FaUserDoctor } from 'react-icons/fa6';
import { LuInfo, LuMail } from "react-icons/lu";
import { useNavigate } from 'react-router-dom';
import '../Header.css';

const Header = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userRole, setUserRole] = useState('');
  const [userName, setUserName] = useState('');
  const [showDropdown, setShowDropdown] = useState(false);
  const navigate = useNavigate();
  const dropdownRef = useRef(null);

  useEffect(() => {
    const doctorId = localStorage.getItem('doctorId');
    const patientId = localStorage.getItem('patientId');
    const doctorName = localStorage.getItem('doctorName');
    const patientName = localStorage.getItem('patientName');
    
    if (doctorId) {
      setIsLoggedIn(true);
      setUserRole('Doctor');
      setUserName(`Dr. ${doctorName || doctorId}`);
    } else if (patientId) {
      setIsLoggedIn(true);
      setUserRole('Patient');
      setUserName(`Hi, ${patientName || patientId}`);
    } else {
      setIsLoggedIn(false);
    }
  }, []);



  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setShowDropdown(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleLogout = () => {
    localStorage.removeItem('doctorId');
    localStorage.removeItem('patientId');
    localStorage.removeItem('doctorName');
    localStorage.removeItem('patientName');
    localStorage.removeItem('userRole');
    setIsLoggedIn(false);
    setUserRole('');
    setUserName('');
    setShowDropdown(false);
    navigate('/');
  };

  return (
    <header className="header">
      <div className="logo"> Hospital Management System</div>
      
      {!isLoggedIn ? (
        <nav className="nav-icons">
          <a href="/" className="nav-link">
            <FaHome /> Home
          </a>
          <a href="#getDoctors" className="nav-link">
            <FaUserDoctor /> Doctor
          </a>
          <a href="/login" className="nav-link">
            <FaSignInAlt /> Login
          </a>
          <a href="#contact" className="nav-link">
            <LuMail /> Contact Us
          </a>
        </nav>
      ) : (
        <div className="user-profile" ref={dropdownRef} onClick={() => setShowDropdown(!showDropdown)}>
          <FaUser className="user-icon" />
          <span className="user-name">{userName}</span>
          <FaChevronDown className={`dropdown-arrow ${showDropdown ? 'rotated' : ''}`} />
          
          {showDropdown && (
            <div className="dropdown-menu">
              <div className="user-details">
                <p>
                  
                </p>
              </div>
              <button className="logout-btn" onClick={handleLogout}>
                <FaSignOutAlt /> Logout
              </button>
            </div>
          )}
        </div>
      )}
    </header>
  );
};

export default Header;
