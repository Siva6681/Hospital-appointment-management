import React, { useState, useEffect } from 'react';
import { FaCalendarPlus, FaCalendarCheck, FaUser, FaChartLine, FaUserEdit, FaBars, FaTimes } from 'react-icons/fa';
import BookAppointment from './BookAppointment';
import ViewAppointments from './ViewAppointments';
import PatientProfile from './PatientProfile';
import '../patientdashboard.css';

const PatientDashboard = () => {
  const [activeSection, setActiveSection] = useState('dashboard');
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [activeSection]);
  const patientId = localStorage.getItem('patientId');
  const patientName = localStorage.getItem('patientName') || 'Patient';

  const renderSection = () => {
    switch (activeSection) {
      case 'bookAppointment':
        return <BookAppointment />;
      case 'viewAppointments':
        return <ViewAppointments />;
      case 'myProfile':
        return <PatientProfile />;
      case 'dashboard':
      default:
        return (
          <div className="dashboard-overview">
            <div className="welcome-section">
              <h1>Welcome, {patientName}!</h1>
              <p>Manage your healthcare appointments and medical records</p>
            </div>

            <div className="quick-actions">
              <button className="action-card" onClick={() => setActiveSection('bookAppointment')}>
                <FaCalendarPlus />
                <h3>Book New Appointment</h3>
                <p>Schedule your next visit</p>
              </button>
              <button className="action-card" onClick={() => setActiveSection('viewAppointments')}>
                <FaCalendarCheck />
                <h3>View Appointments</h3>
                <p>Check your appointment history</p>
              </button>
              <button className="action-card" onClick={() => setActiveSection('myProfile')}>
                <FaUserEdit />
                <h3>My Profile</h3>
                <p>View and edit your profile</p>
              </button>
            </div>
          </div>
        );
    }
  };

  return (
    <div className="patient-dashboard">
      <div className={`dashboard-sidebar ${sidebarCollapsed ? 'collapsed' : ''}`}>
        <div className="sidebar-header">
          <button className="collapse-btn" onClick={() => setSidebarCollapsed(!sidebarCollapsed)}>
            {sidebarCollapsed ? <FaBars /> : <FaTimes />}
          </button>
          {!sidebarCollapsed && (
            <>
              <FaUser className="user-icon" />
              <div className="user-info">
                <h3>{patientName}</h3>
                <p>Patient ID: {patientId}</p>
              </div>
            </>
          )}
        </div>
        <nav className="sidebar-nav">
          <button 
            className={activeSection === 'dashboard' ? 'nav-item active' : 'nav-item'} 
            onClick={() => setActiveSection('dashboard')}
            title="Dashboard"
          >
            <FaChartLine /> {!sidebarCollapsed && 'Dashboard'}
          </button>
          <button 
            className={activeSection === 'bookAppointment' ? 'nav-item active' : 'nav-item'} 
            onClick={() => setActiveSection('bookAppointment')}
            title="Book Appointment"
          >
            <FaCalendarPlus /> {!sidebarCollapsed && 'Book Appointment'}
          </button>
          <button 
            className={activeSection === 'viewAppointments' ? 'nav-item active' : 'nav-item'} 
            onClick={() => setActiveSection('viewAppointments')}
            title="My Appointments"
          >
            <FaCalendarCheck /> {!sidebarCollapsed && 'My Appointments'}
          </button>
          <button 
            className={activeSection === 'myProfile' ? 'nav-item active' : 'nav-item'} 
            onClick={() => setActiveSection('myProfile')}
            title="My Profile"
          >
            <FaUserEdit /> {!sidebarCollapsed && 'My Profile'}
          </button>
        </nav>
      </div>
      <div className="dashboard-main">
        {renderSection()}
      </div>
    </div>
  );
};

export default PatientDashboard;
