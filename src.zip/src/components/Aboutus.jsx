import React from 'react';
import { FaHandsHelping, FaShieldAlt, FaUserMd, FaAward } from 'react-icons/fa';
import '../Aboutus.css';

const Aboutus = () => {
  return (
    <div id="about" className="about-us">
      <section className="about-hero">
        <h1 className="about-hero-title">About Our Hospital</h1>
        <p className="about-hero-subtitle">
          Dedicated to providing exceptional healthcare with compassion, innovation, and excellence
        </p>
      </section>

      <div className="about-content">
        <section className="about-section">
         
        </section>

        <section className="about-section">
          <h2 className="about-section-title">Our Values</h2>
          <div className="values-grid">
            <div className="value-item">
              <FaHandsHelping className="value-icon" />
              <h4 className="value-title">Compassion</h4>
              <p className="value-description">
                We treat every patient with empathy, respect, and understanding.
              </p>
            </div>
            <div className="value-item">
              <FaAward className="value-icon" />
              <h4 className="value-title">Excellence</h4>
              <p className="value-description">
                We strive for the highest standards in medical care and service.
              </p>
            </div>
            <div className="value-item">
              <FaShieldAlt className="value-icon" />
              <h4 className="value-title">Integrity</h4>
              <p className="value-description">
                We maintain honesty and transparency in all our interactions.
              </p>
            </div>
            <div className="value-item">
              <FaUserMd className="value-icon" />
              <h4 className="value-title">Innovation</h4>
              <p className="value-description">
                We embrace new technologies and methods to improve patient care.
              </p>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
};

export default Aboutus;