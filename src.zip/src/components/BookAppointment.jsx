import React, { useState, useEffect, useMemo } from 'react';
import '../BookAppointment.css';

const BookAppointment = () => {
  const [specialties, setSpecialties] = useState([]);
  const [selectedSpecialty, setSelectedSpecialty] = useState('');
  const [doctors, setDoctors] = useState([]);
  const [selectedDoctor, setSelectedDoctor] = useState('');
  const [selectedTimeSlot, setSelectedTimeSlot] = useState('');
  const [cause, setCause] = useState('');
  const [bodyMass, setBodyMass] = useState('');
  const [medicalHistory, setMedicalHistory] = useState('');
  const [availableSlots, setAvailableSlots] = useState([]);

  const patientId = localStorage.getItem('patientId');

  const defaultSlots = useMemo(() => [
    "10:00 AM", "11:00 AM", "12:00 PM", "2:00 PM", "3:00 PM"
  ], []);

  useEffect(() => {
    fetch('http://localhost:8080/api/doctors/specialties')
      .then(res => res.json())
      .then(data => setSpecialties(data))
      .catch(err => console.error('Error fetching specialties:', err));
  }, []);

  useEffect(() => {
    if (selectedSpecialty) {
      fetch(`http://localhost:8080/api/doctors/by-specialty?specialty=${selectedSpecialty}`)
        .then(res => res.json())
        .then(data => setDoctors(data))
        .catch(err => console.error('Error fetching doctors:', err));
    } else {
      setDoctors([]);
      setSelectedDoctor('');
    }
  }, [selectedSpecialty]);

  useEffect(() => {
    if (selectedDoctor) {
      fetch(`http://localhost:8080/api/appointments/doctor/${selectedDoctor}`)
        .then(res => res.json())
        .then(bookedAppointments => {
          const bookedSlots = bookedAppointments.map(app => app.timeSlot);
          const filteredSlots = defaultSlots.filter(slot => !bookedSlots.includes(slot));
          setAvailableSlots(filteredSlots);
        })
        .catch(err => console.error('Error fetching booked slots:', err));
    } else {
      setAvailableSlots([]);
    }
  }, [selectedDoctor, defaultSlots]);



  const handleBookAppointment = async (e) => {
    e.preventDefault();
    const appointmentData = {
      doctor: { doctorId: selectedDoctor },
      patient: { patientId },
      timeSlot: selectedTimeSlot,
      cause,
      bodyMass,
      medicalHistory
    };

    try {
      const response = await fetch('http://localhost:8080/api/appointments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(appointmentData)
      });

      if (response.ok) {
        alert('Appointment booked!');
        setSelectedSpecialty('');
        setDoctors([]);
        setSelectedDoctor('');
        setSelectedTimeSlot('');
        setCause('');
        setBodyMass('');
        setMedicalHistory('');
        setAvailableSlots([]);
      } else {
        const errorMsg = await response.text();
        alert('Booking failed: ' + errorMsg);
      }
    } catch (error) {
      alert('Error: ' + error.message);
    }
  };

  return (
    <div className="book-appointment">
      <div className="appointment-header">
        <h2 className="appointment-title">Book New Appointment</h2>
      </div>
      
      <form className="appointment-form" onSubmit={handleBookAppointment}>
        <div className="form-grid">
          <div className="form-group">
            <label className="form-label">Patient ID</label>
            <input className="form-input" type="text" value={patientId || ''} readOnly />
          </div>

          <div className="form-group">
            <label className="form-label">Specialty</label>
            <select className="form-select" value={selectedSpecialty} onChange={e => setSelectedSpecialty(e.target.value)} required>
              <option value="">Select Specialty</option>
              {specialties.map((spec, index) => (
                <option key={index} value={spec}>{spec}</option>
              ))}
            </select>
          </div>

          <div className="form-group">
            <label className="form-label">Doctor</label>
            <select className="form-select" value={selectedDoctor} onChange={e => setSelectedDoctor(e.target.value)} required>
              <option value="">Select Doctor</option>
              {doctors.map(doc => (
                <option key={doc.doctorId} value={doc.doctorId}>
                  Dr. {doc.name} - {doc.specialty}
                </option>
              ))}
            </select>
          </div>

          <div className="form-group">
            <label className="form-label">Time Slot</label>
            <select className="form-select" value={selectedTimeSlot} onChange={e => setSelectedTimeSlot(e.target.value)} required>
              <option value="">Select Time Slot</option>
              {(availableSlots.length > 0 ? availableSlots : defaultSlots).map(slot => (
                <option key={slot} value={slot}>{slot}</option>
              ))}
            </select>
          </div>

          <div className="form-group">
            <label className="form-label">Reason for Visit</label>
            <input className="form-input" type="text" value={cause} onChange={e => setCause(e.target.value)} placeholder="Brief description of your concern" required />
          </div>

          <div className="form-group">
            <label className="form-label">Body Mass (kg)</label>
            <input className="form-input" type="number" value={bodyMass} onChange={e => setBodyMass(e.target.value)} placeholder="Enter your weight" required />
          </div>

          <div className="form-group full-width">
            <label className="form-label">Medical History</label>
            <textarea className="form-textarea" value={medicalHistory} onChange={e => setMedicalHistory(e.target.value)} placeholder="Please provide relevant medical history, current medications, allergies, etc." required />
          </div>
        </div>

        <button className="submit-button" type="submit">Book Appointment</button>
      </form>
    </div>
  );
};

export default BookAppointment;
