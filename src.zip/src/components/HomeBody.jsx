import React from 'react';
import { FaUserMd, FaCalendarCheck, FaHeartbeat } from 'react-icons/fa';
import '../HomeBody.css';

const HomeBody = () => {
    return (
        <div className="home-body">
            <section className="hero-section">
                <h1 className="hero-title">Your Health, Our Priority</h1>
                <p className="hero-subtitle">
                    Providing world-class healthcare services with compassion, 
                    innovation, and excellence for a healthier tomorrow.
                </p>
                <div className="hero-buttons">
                    <a href="/login" className="hero-btn hero-btn-primary">
                        Book Appointment
                    </a>
                    <a href="#about" className="hero-btn hero-btn-secondary">
                        About Us
                    </a>
                </div>
            </section>

            <section className="features-section">
                <h2 className="section-title">Our Services</h2>
                <div className="features-grid">
                    <div className="feature-card">
                        <FaUserMd className="feature-icon" />
                        <h3 className="feature-title">Expert Doctors</h3>
                        <p className="feature-description">
                            Our team of experienced specialists provide personalized care 
                            with the latest medical technologies.
                        </p>
                    </div>
                    <div className="feature-card">
                        <FaCalendarCheck className="feature-icon" />
                        <h3 className="feature-title">Easy Appointments</h3>
                        <p className="feature-description">
                            Book appointments online with our user-friendly system. 
                            Quick, convenient, and available 24/7.
                        </p>
                    </div>
                    <div className="feature-card">
                        <FaHeartbeat className="feature-icon" />
                        <h3 className="feature-title">Advanced Care</h3>
                        <p className="feature-description">
                            State-of-the-art medical equipment and innovative treatment 
                            methods for comprehensive healthcare.
                        </p>
                    </div>
                    
                </div>
            </section>

            {/* <section className="stats-section">
                <h2 className="section-title">Trusted by Thousands</h2>
                <div className="stats-grid">
                    <div className="stat-item">
                        <span className="stat-number">50+</span>
                        <span className="stat-label">Expert Doctors</span>
                    </div>
                    <div className="stat-item">
                        <span className="stat-number">10K+</span>
                        <span className="stat-label">Happy Patients</span>
                    </div>
                    <div className="stat-item">
                        <span className="stat-number">15+</span>
                        <span className="stat-label">Years Experience</span>
                    </div>
                    <div className="stat-item">
                        <span className="stat-number">24/7</span>
                        <span className="stat-label">Emergency Care</span>
                    </div>
                </div>
            </section> */}
        </div>
    );
};

export default HomeBody;
