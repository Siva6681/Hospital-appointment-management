import React, { useEffect, useState } from 'react';
import '../ViewDoctorsAppointments.css';
 
const ViewDoctorsAppointments = () => {
  const [appointments, setAppointments] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [selectedAppointment, setSelectedAppointment] = useState(null);
  const [prescription, setPrescription] = useState('');
  const [consultationNotes, setConsultationNotes] = useState('');
 
  const doctorId = localStorage.getItem("doctorId");
 
 
  const fetchAppointments = async () => {
    try {
      const response = await fetch(`http://localhost:8080/api/appointments/doctor/${doctorId}`);
      const data = await response.json();
      setAppointments(data);
    } catch (error) {
      console.error('Error fetching appointments:', error);
    }
  };
 
  useEffect(() => {
    fetchAppointments();
  }, [doctorId]);
 
  const openConsultationModal = (appointment) => {
    setSelectedAppointment(appointment);
    setPrescription('');
    setConsultationNotes('');
    setShowModal(true);
  };
 
  const submitConsultation = async () => {
    try {
      const response = await fetch('http://localhost:8080/api/consultations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          appointment: { appointmentId: selectedAppointment.appointmentId },
          prescription,
          consultationNotes,
        }),
      });
      
 
      if (response.ok) {
        alert('Consultation submitted successfully.');
        setShowModal(false);
        fetchAppointments();
      } else {
        alert('Failed to submit consultation.');
      }
    } catch (error) {
      console.error('Error submitting consultation:', error);
    }
  };
 
  const cancelAppointment = async (appointmentId) => {
    try {
      const response = await fetch(`http://localhost:8080/api/appointments/${appointmentId}`, {
        method: 'DELETE'
      });
      if (response.ok) {
        alert('Appointment deleted.');
        fetchAppointments();
      } else {
        alert('Failed to delete appointment.');
      }
    } catch (error) {
      console.error('Error deleting appointment:', error);
    }
  };
 
  return (
    <div className="doctor-appointments">
      <div className="doctor-appointments-header">
        <h2 className="doctor-appointments-title">My Appointments</h2>
        <p className="doctor-appointments-subtitle">Manage your patient appointments and consultations</p>
      </div>
      
      <div className="appointments-container">
        {appointments.length === 0 ? (
          <div className="no-appointments-message">
            <div className="no-appointments-icon">📅</div>
            <p className="no-appointments-text">No appointments scheduled</p>
          </div>
        ) : (
          <div className="appointments-grid">
            {appointments.map((appointment) => (
              <div key={appointment.appointmentId} className="doctor-appointment-card">
                <div className="appointment-card-header">
                  <div className="patient-info">
                    <div className="patient-name">{appointment.patient.name}</div>
                    <div className="patient-id">Age: {appointment.patient.age}</div>
                  </div>
                  <div className="appointment-time-info">
                    <div className="appointment-date-time">{appointment.timeSlot}</div>
                    <div className="appointment-duration">ID: {appointment.appointmentId}</div>
                  </div>
                </div>
                
                <div className="appointment-details-grid">
                  <div className="detail-box">
                    <div className="detail-box-label">Reason</div>
                    <div className="detail-box-value">{appointment.cause}</div>
                  </div>
                  <div className="detail-box">
                    <div className="detail-box-label">Body Mass</div>
                    <div className="detail-box-value">{appointment.bodyMass} kg</div>
                  </div>
                </div>
                
                <div className="appointment-notes">
                  <div className="notes-label">Medical History</div>
                  <div className="notes-text">{appointment.medicalHistory}</div>
                </div>
                
                <div className="appointment-status-section">
                  <span className={`status-badge status-${appointment.status?.toLowerCase() || 'booked'}`}>
                    {appointment.status || 'Booked'}
                  </span>
                </div>
                
                {appointment.status === 'Booked' && (
                  <div className="appointment-card-actions">
                    <button className="action-btn btn-complete" onClick={() => openConsultationModal(appointment)}>
                      Complete Consultation
                    </button>
                    <button className="action-btn btn-cancel" onClick={() => cancelAppointment(appointment.appointmentId)}>
                      Cancel
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      {showModal && (
        <div className="modal-overlay">
          <div className="consultation-modal">
            <div className="modal-content">
              <h3>Complete Consultation</h3>
              <p>Patient: {selectedAppointment?.patient.name} (ID: {selectedAppointment?.appointmentId})</p>
              
              <div className="form-group">
                <label className="form-label">Prescription:</label>
                <textarea
                  className="form-textarea"
                  value={prescription}
                  onChange={(e) => setPrescription(e.target.value)}
                  placeholder="Enter prescription details..."
                  rows={4}
                />
              </div>
              
              <div className="form-group">
                <label className="form-label">Consultation Notes:</label>
                <textarea
                  className="form-textarea"
                  value={consultationNotes}
                  onChange={(e) => setConsultationNotes(e.target.value)}
                  placeholder="Enter consultation notes..."
                  rows={4}
                />
              </div>
              
              <div className="modal-actions">
                <button className="btn-submit" onClick={submitConsultation}>
                  Submit Consultation
                </button>
                <button className="btn-close" onClick={() => setShowModal(false)}>
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
 
export default ViewDoctorsAppointments;