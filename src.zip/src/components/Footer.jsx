import React from 'react';
import '../Footer.css';
import { FaFacebookF, FaTwitter, FaLinkedinIn } from 'react-icons/fa';

const Footer = () => {
  return (
    <footer id='contact' className="footer">
      <div className="footer-content">
        {/* Left Section */}
        <div className="footer-section">
          <h3>HealthCare</h3>
          <p>Your trusted partner for appointments and quality care.</p>
          <div className="social-icons">
            <a href="https://www.facebook.com/"><FaFacebookF /></a>
            <a href="https://x.com/"><FaTwitter /></a>
            <a href="https://Linkedin.com"><FaLinkedinIn /></a>
          </div>
        </div>

        

        {/* Right Section */}
        <div className="footer-section">
          <h3>Contact</h3>
          <p>Email: HAMS@support.com</p>
          <p>Phone: +91 9xxxxxxxxx</p>
          <p>Address: 1/2B, Andavar nagar, Ramapuram, Chennai-89 </p>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="footer-bottom">
       <p>&copy; {new Date().getFullYear()} Hospital Management System. All rights reserved.</p>
        <div className="footer-links">
          {/* <a href="#">Privacy</a>
          <a href="#">Terms</a>
          <a href="#">Support</a> */}
          <a href="#top" className="back-to-top">Back to top ↑</a>

        </div>
      </div>
    </footer>
  );
};

export default Footer;
