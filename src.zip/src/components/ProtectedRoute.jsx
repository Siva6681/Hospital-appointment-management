import React, { useEffect } from 'react';
import { Navigate } from 'react-router-dom';

const ProtectedRoute = ({ children, requiredRole }) => {
    const doctorId = localStorage.getItem('doctorId');
    const patientId = localStorage.getItem('patientId');
    const isAuthenticated = doctorId || patientId;
    
    useEffect(() => {
        if (!isAuthenticated) {
            alert('Please login first to access this page!');
        }
    }, [isAuthenticated]);
    
    if (!isAuthenticated) {
        return <Navigate to="/login" replace />;
    }
    
    if (requiredRole === 'doctor' && !doctorId) {
        alert('Access denied! Doctor login required.');
        return <Navigate to="/login" replace />;
    }
    
    if (requiredRole === 'patient' && !patientId) {
        alert('Access denied! Patient login required.');
        return <Navigate to="/login" replace />;
    }
    
    return children;
};

export default ProtectedRoute;
