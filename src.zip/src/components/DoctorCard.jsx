import React from 'react';
import { FaUserMd } from 'react-icons/fa';
import '../DoctorCard.css';

const DoctorCard = ({ doctor }) => {
  return (
    <div className="doctor-card">
      <div className="doctor-icon">
        <FaUserMd />
      </div>
      <h3 className="doctor-name">Dr. {doctor.name}</h3>
      <p className="doctor-specialty">{doctor.specialty}</p>
      {/* <p className="doctor-age">Age: {doctor.age}</p> */}
    </div>
  );
};

export default DoctorCard;