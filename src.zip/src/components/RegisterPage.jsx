import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import '../RegisterPage.css';

const RegisterPage = () => {
  const navigate = useNavigate();
  
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);
  const [role, setRole] = useState('');
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    password: '',
    phoneNumber: '',
    gender: '',
    age: '',
    specialty: '',
  });
  const [loading, setLoading] = useState(false);

  const getPasswordValidationMessage = (password) => {
    const messages = [];
    const hasMinLength = password.length >= 8;
    const hasCapital = /[A-Z]/.test(password);
    const hasDigit = /[0-9]/.test(password);
    const hasSpecialChar = /[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(password);

    if (!hasMinLength) messages.push('Min. 8 characters');
    if (!hasCapital) messages.push('Min. 1 capital letter');
    if (!hasDigit) messages.push('Min. 1 digit');
    if (!hasSpecialChar) messages.push('Min. 1 special character');

    if (messages.length === 0 && password.length > 0) {
      return 'Password meets all requirements!';
    } else if (password.length === 0) {
      return 'Enter a password to see requirements.';
    } else {
      return `Password should have: ${messages.join(', ')}.`;
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    
    if (name === 'phoneNumber') {
      // Only allow digits and limit to 10 characters
      const numericValue = value.replace(/[^0-9]/g, '').slice(0, 10);
      setFormData((prev) => ({ ...prev, [name]: numericValue }));
    } else {
      setFormData((prev) => ({ ...prev, [name]: value }));
    }
    
    if (name === 'role') setRole(value);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    let url = '';
    let payload = {};

    if (role === 'doctor') {
      url = 'http://localhost:8080/api/doctors/register';
      payload = {
        name: formData.fullName,
        email: formData.email,
        phoneNumber: formData.phoneNumber,
        specialty: formData.specialty,
        password: formData.password,
        age: formData.age,
        gender: formData.gender,
      };
    } else if (role === 'patient') {
      url = 'http://localhost:8080/api/patients/register';
      payload = {
        name: formData.fullName,
        email: formData.email,
        password: formData.password,
        phoneNumber: formData.phoneNumber,
        gender: formData.gender,
        age: formData.age,
      };
    } else {
      alert('Please select a role');
      setLoading(false);
      return;
    }

    const hasMinLength = formData.password.length >= 8;
    const hasCapital = /[A-Z]/.test(formData.password);
    const hasDigit = /[0-9]/.test(formData.password);
    const hasSpecialChar = /[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(formData.password);

    if (!hasMinLength || !hasCapital || !hasDigit || !hasSpecialChar) {
      alert('Please meet all password requirements before submitting.');
      setLoading(false);
      return;
    }

    if (formData.phoneNumber.length !== 10) {
      alert('Phone number must be exactly 10 digits.');
      setLoading(false);
      return;
    }

    if (formData.age > 110 || formData.age <0) {
      alert('Give correct age');
      setLoading(false);
      return;
    }

    try {
      const response = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      const data = await response.json();
      if (response.ok) {
        alert(`${role === 'patient' ? 'Patient' : 'Doctor'} registered successfully!`);
        navigate('/login');
        window.scrollTo(0, 0);
      } else {
        alert(data.message || 'Registration failed');
      }
    } catch (error) {
      console.error('Registration error:', error);
      alert('An unexpected error occurred. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="register-page">
      <div className="register-container">
        <h2>Register</h2>
        <form className="register-form" onSubmit={handleSubmit}>
          <input type="text" name="fullName" placeholder="Full Name" value={formData.fullName} onChange={handleChange} required />
          <input type="email" name="email" placeholder="Email Address" value={formData.email} onChange={handleChange} required />
          <input 
            type="tel" 
            name="phoneNumber" 
            placeholder="Phone Number (10 digits)" 
            value={formData.phoneNumber} 
            onChange={handleChange} 
            maxLength="10"
            pattern="[0-9]{10}"
            title="Please enter exactly 10 digits"
            required 
          />
          <input type="password" name="password" placeholder="Password" value={formData.password} onChange={handleChange} required />
          <p className="password-strength">{getPasswordValidationMessage(formData.password)}</p>

          <select name="role" value={role} onChange={handleChange} required>
            <option value="">Select Role</option>
            <option value="doctor">Doctor</option>
            <option value="patient">Patient</option>
          </select>

          {role === 'doctor' && (
            <input type="text" name="specialty" placeholder="Specialty" value={formData.specialty} onChange={handleChange} required />
          )}

          <input type="number" name="age" placeholder="Age" value={formData.age} onChange={handleChange} min="25" max="99" required />
          <select name="gender" value={formData.gender} onChange={handleChange} required>
            <option value="">Select Gender</option>
            <option value="Male">Male</option>
            <option value="Female">Female</option>
            <option value="Others">Others</option>
          </select>

          <button type="submit" disabled={loading}>
            {loading ? 'Registering...' : 'Register'}
          </button>
        </form>
        <div className="login-redirect">
          Already have an account? <Link to="/login">Login here</Link>
        </div>
      </div>
    </div>
  );
};

export default RegisterPage;
