import React, { useState } from 'react';
import { FaSearch, FaCalendarCheck } from 'react-icons/fa';
import '../SearchBooking.css';
 
const SearchBooking = () => {
  const [appointmentId, setAppointmentId] = useState('');
  const [appointmentDetails, setAppointmentDetails] = useState(null);
  const [error, setError] = useState('');
 
  const handleSearch = async () => {
    if (!appointmentId.trim()) return;
 
    try {
      const response = await fetch(`http://localhost:8080/api/appointments/${appointmentId}`);
      const data = await response.json();
      console.log(data);
      if (response.ok) {
        setAppointmentDetails(data);
        setError('');
      } else {
        setAppointmentDetails(null);
        setError(data.message || 'Appointment not found');
      }
    } catch (err) {
      setAppointmentDetails(null);
      setError('Error fetching appointment details');
    }
  };
 
  return (
    <div className="search-booking">
      <div className="search-container">
        <h3><FaSearch /> Search Appointment</h3>
        <div className="search-form">
          <input
            type="text"
            placeholder="Enter Appointment ID"
            value={appointmentId}
            onChange={(e) => setAppointmentId(e.target.value)}
          />
          <button onClick={handleSearch}>
            <FaSearch /> Search
          </button>
        </div>
 
        {error && <p className="error">{error}</p>}
 
        {appointmentDetails && (
          <div className="booking-details">
            <h4><FaCalendarCheck /> Appointment Details</h4>
            <div className="detail-grid">
              <div className="detail-item">
                <p><strong>ID:</strong> {appointmentDetails.appointmentId}</p>
              </div>
              <div className="detail-item">
                <p><strong>Time Slot:</strong> {appointmentDetails.timeSlot}</p>
              </div>
              <div className="detail-item">
                <p><strong>Patient:</strong> {appointmentDetails.patientName}</p>
              </div>
              <div className="detail-item">
                <p><strong>Gender:</strong> {appointmentDetails.patientGender}</p>
              </div>
              <div className="detail-item">
                <p><strong>Age:</strong> {appointmentDetails.patientAge}</p>
              </div>
              <div className="detail-item">
                <p><strong>Status:</strong> {appointmentDetails.status}</p>
              </div>
            </div>
            <div className="detail-item" style={{marginTop: '1rem'}}>
              <p><strong>Cause:</strong> {appointmentDetails.cause}</p>
              <p><strong>Medical History:</strong> {appointmentDetails.medicalHistory}</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
 
export default SearchBooking;