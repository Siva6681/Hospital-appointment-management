import React from 'react';
import Header from './Header';
import HomeBody from './HomeBody';
import Aboutus from './Aboutus';
import Footer from './Footer';
import GetDoctors from './GetDoctors';


export default function Home (){
    return(
    <div>
        {/* <Header /> */}
        <HomeBody />
        <GetDoctors />
        <Aboutus />
        
        {/* <Footer /> */}
    </div>
    );
}



    
