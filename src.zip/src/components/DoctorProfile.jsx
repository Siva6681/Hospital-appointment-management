import React, { useState, useEffect } from 'react';
import { FaStethoscope, FaEdit, FaSave, FaTimes, FaEye, FaEyeSlash } from 'react-icons/fa';
import '../DoctorProfile.css';

const DoctorProfile = () => {
  const [profile, setProfile] = useState({
    name: '',
    email: '',
    age: '',
    gender: '',
    phoneNumber: '',
    specialty: '',
    password: ''
  });
  const [isEditing, setIsEditing] = useState(false);
  const [loading, setLoading] = useState(true);
  const [showPassword, setShowPassword] = useState(false);

  const doctorId = localStorage.getItem('doctorId');

  useEffect(() => {
    console.log('DoctorProfile component mounted');
    console.log('Doctor ID from localStorage:', doctorId);
    if (doctorId) {
      fetchProfile();
    } else {
      console.log('No doctor ID found in localStorage');
      setLoading(false);
    }
  }, []);

  const fetchProfile = async () => {
    console.log('=== FETCHING DOCTOR PROFILE ===');
    console.log('Doctor ID:', doctorId);
    console.log('API URL:', `http://localhost:8080/api/doctors/${doctorId}`);
    
    try {
      const response = await fetch(`http://localhost:8080/api/doctors/${doctorId}`);
      console.log('Response status:', response.status);
      console.log('Response ok:', response.ok);
      
      if (response.ok) {
        const data = await response.json();
        console.log('Doctor profile data received:', data);
        setProfile(data);
      } else {
        console.log('Response not ok, status:', response.status);
        const errorText = await response.text();
        console.log('Error response:', errorText);
      }
    } catch (error) {
      console.error('Error fetching doctor profile:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setProfile(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSave = async () => {
    try {
      const response = await fetch(`http://localhost:8080/api/doctors/${doctorId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(profile)
      });

      if (response.ok) {
        alert('Profile updated successfully!');
        setIsEditing(false);
        setShowPassword(false);
        // Update localStorage with new name
        localStorage.setItem('doctorName', profile.name);
      } else {
        alert('Failed to update profile');
      }
    } catch (error) {
      console.error('Error updating profile:', error);
      alert('Error updating profile');
    }
  };

  const handleCancel = () => {
    setIsEditing(false);
    setShowPassword(false);
    fetchProfile(); // Reset to original data
  };

  if (loading) {
    return <div className="loading">Loading profile...</div>;
  }

  return (
    <div className="doctor-profile">
      <div className="profile-header">
        <h2 className="profile-title">
          <FaStethoscope /> My Profile
        </h2>
        <p className="profile-subtitle">View and manage your professional information</p>
      </div>

      <div className="profile-container">
        <div className="profile-card">
          <div className="profile-actions">
            {!isEditing ? (
              <button className="btn-edit" onClick={() => setIsEditing(true)}>
                <FaEdit /> Edit Profile
              </button>
            ) : (
              <div className="edit-actions">
                <button className="btn-save" onClick={handleSave}>
                  <FaSave /> Save
                </button>
                <button className="btn-cancel" onClick={handleCancel}>
                  <FaTimes /> Cancel
                </button>
              </div>
            )}
          </div>

          <div className="profile-form">
            <div className="form-grid">
              <div className="form-group">
                <label className="form-label">Full Name</label>
                {isEditing ? (
                  <input
                    type="text"
                    name="name"
                    value={profile.name}
                    onChange={handleInputChange}
                    className="form-input"
                  />
                ) : (
                  <div className="form-value">{profile.name}</div>
                )}
              </div>

              <div className="form-group">
                <label className="form-label">Email</label>
                {isEditing ? (
                  <input
                    type="email"
                    name="email"
                    value={profile.email}
                    onChange={handleInputChange}
                    className="form-input"
                  />
                ) : (
                  <div className="form-value">{profile.email}</div>
                )}
              </div>

              <div className="form-group">
                <label className="form-label">Age</label>
                {isEditing ? (
                  <input
                    type="number"
                    name="age"
                    value={profile.age}
                    onChange={handleInputChange}
                    className="form-input"
                  />
                ) : (
                  <div className="form-value">{profile.age}</div>
                )}
              </div>

              <div className="form-group">
                <label className="form-label">Gender</label>
                {isEditing ? (
                  <select
                    name="gender"
                    value={profile.gender}
                    onChange={handleInputChange}
                    className="form-select"
                  >
                    <option value="">Select Gender</option>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    <option value="Other">Other</option>
                  </select>
                ) : (
                  <div className="form-value">{profile.gender}</div>
                )}
              </div>

              <div className="form-group">
                <label className="form-label">Specialty</label>
                {isEditing ? (
                  <input
                    type="text"
                    name="specialty"
                    value={profile.specialty}
                    onChange={handleInputChange}
                    className="form-input"
                  />
                ) : (
                  <div className="form-value">{profile.specialty}</div>
                )}
              </div>

              <div className="form-group">
                <label className="form-label">Phone Number</label>
                {isEditing ? (
                  <input
                    type="tel"
                    name="phoneNumber"
                    value={profile.phoneNumber}
                    onChange={handleInputChange}
                    className="form-input"
                  />
                ) : (
                  <div className="form-value">{profile.phoneNumber}</div>
                )}
              </div>

              <div className="form-group">
                <label className="form-label">Password</label>
                {isEditing ? (
                  <div style={{position: 'relative'}}>
                    <input
                      type={showPassword ? "text" : "password"}
                      name="password"
                      value={profile.password}
                      onChange={handleInputChange}
                      className="form-input"
                      placeholder="Enter new password"
                      style={{paddingRight: '3rem'}}
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      style={{
                        position: 'absolute',
                        right: '1rem',
                        top: '50%',
                        transform: 'translateY(-50%)',
                        background: 'none',
                        border: 'none',
                        color: '#00ACC1',
                        cursor: 'pointer',
                        padding: '0.5rem'
                      }}
                    >
                      {showPassword ? <FaEyeSlash /> : <FaEye />}
                    </button>
                  </div>
                ) : (
                  <div className="form-value">••••••••</div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DoctorProfile;