import React, { useEffect, useState } from 'react';
import '../ViewAppointments.css';
import axios from 'axios';
import Modal from 'react-modal';

const ViewAppointments = () => {
  const [appointments, setAppointments] = useState([]);
  const patientId = localStorage.getItem('patientId');
  const [selectedConsultation, setSelectedConsultation] = useState(null);
  const [modalIsOpen, setModalIsOpen] = useState(false);
  const [loading, setLoading] = useState(false);

  const fetchAppointments = async () => {
    try {
      const response = await fetch(`http://localhost:8080/api/appointments/patient/${patientId}`);
      if (!response.ok) {
        throw new Error('Failed to fetch appointments');
      }
      const data = await response.json();
      setAppointments(data);
    } catch (error) {
      console.error(error);
    }
  };

  useEffect(() => {
    fetchAppointments();
  }, [patientId]);

  const handleDelete = async (appointmentId) => {
    try {
      const response = await axios.delete(`http://localhost:8080/api/appointments/${appointmentId}`);
      if (response.status === 200) {
        setAppointments(prev => prev.filter(a => a.appointmentId !== appointmentId));
        alert('Appointment Deleted');
      } else {
        alert('Failed to delete appointment');
      }
    } catch (error) {
      console.error(error);
      alert('Error deleting appointment');
    }
  };

  const openConsultationModal = async (appointment) => {
    setLoading(true);
    try {
      const response = await fetch(`http://localhost:8080/api/consultations/appointment/${appointment.appointmentId}`);
      if (!response.ok) {
        throw new Error('Failed to fetch consultation details');
      }
      const consultationData = await response.json();
      setSelectedConsultation(consultationData);
      setModalIsOpen(true);
    } catch (error) {
      console.error(error);
      alert('Consultation details not found.');
    } finally {
      setLoading(false);
    }
  };

  const closeModal = () => {
    setModalIsOpen(false);
    setSelectedConsultation(null);
  };

  return (
    <div className="view-appointments">
      <div className="appointments-header">
        <h2 className="appointments-title">My Appointments</h2>
        <p className="appointments-subtitle">View and manage your scheduled appointments</p>
      </div>
      
      <div className="appointments-container">
        {appointments.length === 0 ? (
          <div className="no-appointments">
            <div className="no-appointments-icon">📅</div>
            <p className="no-appointments-text">No appointments found</p>
            <p>Book your first appointment to get started</p>
          </div>
        ) : (
          <div className="appointments-list">
            {appointments.map((appointment) => (
              <div key={appointment.appointmentId} className="appointment-item">
                <div className="appointment-header">
                  <div className="appointment-info">
                    <div className="appointment-date">Appointment #{appointment.appointmentId}</div>
                    <div className="appointment-time">{appointment.timeSlot}</div>
                  </div>
                  <div className={`appointment-status status-${appointment.status?.toLowerCase() || 'booked'}`}>
                    {appointment.status || 'Booked'}
                  </div>
                </div>
                
                <div className="appointment-details">
                  <div className="detail-item">
                    <span className="detail-label">Doctor:</span>
                    <span className="detail-value">Dr. {appointment.doctor.name}</span>
                  </div>
                  <div className="detail-item">
                    <span className="detail-label">Reason:</span>
                    <span className="detail-value">{appointment.cause}</span>
                  </div>
                  <div className="detail-item full-width">
                    <span className="detail-label">Medical History:</span>
                    <span className="detail-value">{appointment.medicalHistory}</span>
                  </div>
                </div>
                
                <div className="appointment-actions">
                  {appointment.status === 'completed' && (
                    <button className="btn-view-consultation" onClick={() => openConsultationModal(appointment)}>
                      View Consultation
                    </button>
                  )}
                  {appointment.status === 'Booked' && (
                    <button className="btn-cancel" onClick={() => handleDelete(appointment.appointmentId)}>
                      Cancel Appointment
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <Modal
        isOpen={modalIsOpen}
        onRequestClose={closeModal}
        className="consultation-modal"
        overlayClassName="modal-overlay"
      >
        <div className="modal-content">
          <h2>Consultation Details</h2>
          {loading ? (
            <p>Loading consultation details...</p>
          ) : selectedConsultation ? (
            <div className="consultation-details">
              <div className="consultation-item">
                <strong>Prescription:</strong>
                <p>{selectedConsultation.prescription}</p>
              </div>
              <div className="consultation-item">
                <strong>Doctor's Notes:</strong>
                <p>{selectedConsultation.consultationNotes}</p>
              </div>
            </div>
          ) : (
            <p>No consultation data available.</p>
          )}
          <button className="close-button" onClick={closeModal}>Close</button>
        </div>
      </Modal>
    </div>
  );
};

export default ViewAppointments;
